import '/components/wind_compass_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'area300_widget.dart' show Area300Widget;
import 'package:flutter/material.dart';

class Area300Model extends FlutterFlowModel<Area300Widget> {
  ///  State fields for stateful widgets in this page.

  // Model for WindCompass component.
  late WindCompassModel windCompassModel;

  @override
  void initState(BuildContext context) {
    windCompassModel = createModel(context, () => WindCompassModel());
  }

  @override
  void dispose() {
    windCompassModel.dispose();
  }
}
