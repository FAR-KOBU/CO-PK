import '/components/wind_compass_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'area200_widget.dart' show Area200Widget;
import 'package:flutter/material.dart';

class Area200Model extends FlutterFlowModel<Area200Widget> {
  ///  State fields for stateful widgets in this page.

  // Model for WindCompass component.
  late WindCompassModel windCompassModel;

  @override
  void initState(BuildContext context) {
    windCompassModel = createModel(context, () => WindCompassModel());
  }

  @override
  void dispose() {
    windCompassModel.dispose();
  }
}
