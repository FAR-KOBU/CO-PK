import '/flutter_flow/flutter_flow_util.dart';
import 'meal_bottom_sheet_widget.dart' show MealBottomSheetWidget;
import 'package:flutter/material.dart';

class MealBottomSheetModel extends FlutterFlowModel<MealBottomSheetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
