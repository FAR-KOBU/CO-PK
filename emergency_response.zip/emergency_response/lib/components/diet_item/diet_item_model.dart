import '/flutter_flow/flutter_flow_util.dart';
import 'diet_item_widget.dart' show DietItemWidget;
import 'package:flutter/material.dart';

class DietItemModel extends FlutterFlowModel<DietItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
