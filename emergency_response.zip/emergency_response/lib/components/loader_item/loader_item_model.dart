import '/flutter_flow/flutter_flow_util.dart';
import 'loader_item_widget.dart' show LoaderItemWidget;
import 'package:flutter/material.dart';

class LoaderItemModel extends FlutterFlowModel<LoaderItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
