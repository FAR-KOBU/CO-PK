import '/flutter_flow/flutter_flow_util.dart';
import 'wind_compass_widget.dart' show WindCompassWidget;
import 'package:flutter/material.dart';

class WindCompassModel extends FlutterFlowModel<WindCompassWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
