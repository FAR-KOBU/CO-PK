import '/flutter_flow/flutter_flow_util.dart';
import 'status_level_widget.dart' show StatusLevelWidget;
import 'package:flutter/material.dart';

class StatusLevelModel extends FlutterFlowModel<StatusLevelWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for Checkbox widget.
  bool? checkboxValue1;
  // State field(s) for Checkbox widget.
  bool? checkboxValue2;
  // State field(s) for Checkbox widget.
  bool? checkboxValue3;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
