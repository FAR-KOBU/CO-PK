import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'incident_details_model.dart';
export 'incident_details_model.dart';

class IncidentDetailsWidget extends StatefulWidget {
  const IncidentDetailsWidget({super.key});

  static String routeName = 'IncidentDetails';
  static String routePath = 'IncidentDetails';

  @override
  State<IncidentDetailsWidget> createState() => _IncidentDetailsWidgetState();
}

class _IncidentDetailsWidgetState extends State<IncidentDetailsWidget> {
  late IncidentDetailsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IncidentDetailsModel());

    logFirebaseEvent('screen_view',
        parameters: {'screen_name': 'IncidentDetails'});
    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        leading: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            logFirebaseEvent('INCIDENT_DETAILS_Icon_ufguk4w8_ON_TAP');
            logFirebaseEvent('Icon_navigate_back');
            context.pop();
          },
          child: Icon(
            Icons.chevron_left_rounded,
            color: Color(0xFF0F1113),
            size: 32.0,
          ),
        ),
        title: Text(
          'Area Details',
          style: FlutterFlowTheme.of(context).headlineMedium.override(
                font: GoogleFonts.outfit(
                  fontWeight: FontWeight.w500,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                ),
                color: Color(0xFF0F1113),
                fontSize: 24.0,
                letterSpacing: 0.0,
                fontWeight: FontWeight.w500,
                fontStyle:
                    FlutterFlowTheme.of(context).headlineMedium.fontStyle,
              ),
        ),
        actions: [],
        centerTitle: false,
        elevation: 0.0,
      ),
      body: SafeArea(
        top: true,
        child: Stack(
          children: [
            Container(
              width: 396.2,
              height: 745.9,
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  FlutterFlowPdfViewer(
                    assetPath: 'assets/pdfs/PCMTBE-01_04-L3-59877_REV_2.pdf',
                    height: 300.0,
                    horizontalScroll: false,
                  ),
                  Divider(
                    thickness: 2.0,
                    color: FlutterFlowTheme.of(context).alternate,
                  ),
                  Spacer(),
                  FlutterFlowPdfViewer(
                    assetPath: 'assets/pdfs/PCMTBE-02_04-L3-056953_REV_2.pdf',
                    height: 300.0,
                    horizontalScroll: false,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
