import '/flutter_flow/flutter_flow_util.dart';
import 'incident_details_widget.dart' show IncidentDetailsWidget;
import 'package:flutter/material.dart';

class IncidentDetailsModel extends FlutterFlowModel<IncidentDetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
